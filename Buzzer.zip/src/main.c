#include"stm32f10x.h"

#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2))
#define MEM_ADDR(addr) *((volatile unsigned long *)(addr))
#define BIT_ADDR(addr, bitnum) MEM_ADDR(BITBAND(addr, bitnum))
#define GPIOA_ODR_Addr (GPIOA_BASE+12)
#define GPIOB_ODR_Addr (GPIOB_BASE+12)
#define LED0 BIT_ADDR(GPIOA_ODR_Addr,5) //LED0��ӦPA5
#define BEEP BIT_ADDR(GPIOB_ODR_Addr,8)

void delay_ms(int32_t ms)
{
    int32_t i;
    while(ms--)
    {
        i = 7500;
        while(i--);
    }
}

void Buzzer_Init(void)
{
 GPIO_InitTypeDef  G;
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
 G.GPIO_Pin = GPIO_Pin_8;
 G.GPIO_Mode = GPIO_Mode_Out_PP;
 G.GPIO_Speed = GPIO_Speed_50MHz;
 GPIO_Init(GPIOB, &G);
 GPIO_ResetBits(GPIOB,GPIO_Pin_8);
}

void LED_Init()
{
	GPIO_InitTypeDef G;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	G.GPIO_Speed=GPIO_Speed_50MHz;
	G.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA,&G);
	GPIO_SetBits(GPIOA,GPIO_Pin_5);
}

int main(void)
 {
	LED_Init();
	Buzzer_Init();
	while(1)
	{
		LED0=0;
		BEEP=0;
		delay_ms(300);
		LED0=1;
		BEEP=1;
		delay_ms(300);
	}
 }
