#include "stm32f10x.h"

#define KEY0 GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_13)
#define KEY_PRESS 1
#define Buzzer_TOGGLE {GPIOB->ODR ^= GPIO_Pin_8;}
int tune;

void TIM_4(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	TIM_TimeBaseStructure.TIM_Period = 1;
	TIM_TimeBaseStructure.TIM_Prescaler = (72 - 1);
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Down;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
}

void Buzzer_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_SetBits(GPIOB,GPIO_Pin_8);
}

void LED_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void SysTick_Init(int n)
{
	if (SysTick_Config(SystemCoreClock / 1000000 * n))
	{
		while (1);
	}
}

void delay_us(unsigned int nus)
{
	TIM4->CNT = nus - 1;
	TIM4->CR1 |= TIM_CR1_CEN;
	while ((TIM4->SR & TIM_FLAG_Update) != SET);
	TIM4->CR1 &= (~TIM_CR1_CEN);
	TIM4->SR &= ~(TIM_FLAG_Update);
}

void delay_ms(unsigned int nms)
{
	int count;
	for (count = 0; count < nms; count++)
		delay_us(1000);
}

void Key_Init()
{
	GPIO_InitTypeDef G;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	G.GPIO_Pin = GPIO_Pin_13;
	G.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_Init(GPIOC,&G);
}

uint8_t KeyScan()
{
	if(KEY0==0)
	{
		delay_ms(10);
		if(KEY0==0)
			return KEY_PRESS;
		else
			return 0;
	}
	else
		return 0;
}

enum frequency
{
	l_do = 262,l_re = 286,l_mi = 311,l_fa = 349,l_so = 392,l_ra = 440,l_si = 494,
	m_do = 523,m_re = 587,m_mi = 659,m_fa = 698,m_so = 784,m_ra = 880,m_si = 987,
	h_do = 1046,h_re = 1174,h_mi = 1318,h_fa = 1396,h_so = 1567,h_ra = 1760,h_si = 1975
};

unsigned int melody[] =
	{
			m_so,m_ra,m_re,m_mi,m_do,h_re,m_re,m_do,m_do,m_re,
			h_re,m_re,m_do,m_do,m_re,m_mi,m_so,m_ra,m_mi,m_so,m_re,m_mi,m_do,m_re,m_do,
			m_mi,m_so,m_ra,m_mi,m_so,m_re,m_mi,m_do,m_re,m_mi,h_re,m_re,m_do,m_re,
			h_re,m_do,m_re,m_mi,m_so,m_re,m_mi,m_re,m_do,m_re,m_do,m_re,
			m_so,m_ra,m_re,m_mi,m_do,h_re,m_re,m_do,m_do,m_re,
			h_re,m_re,m_do,m_do,m_re,m_mi,m_so,m_ra,m_mi,m_so,m_re,m_mi,m_do,m_re,m_do,
			m_mi,m_so,m_ra,m_mi,m_so,m_re,m_mi,m_do,m_re,m_mi,h_re,m_re,m_do,m_re,
			h_re,m_do,m_re,m_mi,m_so,m_re,m_mi,m_re,m_do,m_re,m_do,m_do,
			m_do,l_so,l_ra,m_do,l_so,l_ra,m_do,m_re,m_mi,m_do,m_fa,m_mi,m_fa,m_so,
			m_do,m_do,l_so,l_ra,m_do,l_so,m_fa,m_mi,m_re,m_do,l_so,l_mi,l_so,m_do,
			m_do,l_so,l_ra,m_do,l_so,l_ra,m_do,m_do,m_re,m_mi,m_do,l_so,l_ra,l_so,
			m_do,m_do,l_si,m_do,l_so,l_ra,m_do,m_fa,m_mi,m_fa,m_so,m_do,l_si,
			m_do,m_do,l_si,m_do,l_so,l_ra,m_do,m_fa,m_mi,m_fa,m_so,m_do,m_re,
			0xff
	};

unsigned char beats[] = {
		2,2, 1,2,1, 1,1,2, 2,2,
		2,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1,
		2,2, 1,1,1,1, 1,1,1,1, 1,1,1,1,
		2,1,1, 1,1,1,1, 1,1,2, 2,2,
		2,2, 1,2,1, 1,1,2, 2,2,
		2,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1,
		2,2, 1,1,1,1, 1,1,1,1, 1,1,1,1,
		2,1,1, 1,1,1,1, 1,1,2, 2,2,
		2,1,1, 2,1,1, 1,1,1,1, 1,1,1,1,
		2,2, 1,1,1,1, 1,1,1,1, 1,1,1,1,
		2,1,1, 2,1,1, 1,1,1,1, 1,1,1,1,
		2,1,1, 1,1,1,1, 1,1,1,1, 2,2,
		2,1,1, 2,1,1, 1,1,1,1, 1,1,1,1,
		2,2, 1,1,1,1, 1,1,1,1, 1,1,1,1,
		2,1,1, 2,1,1, 1,1,1,1, 1,1,1,1,
		2,1,1, 1,1,1,1, 1,1,1,1, 2,2
};

int main(void)
{
	int i;
	int j;
	TIM_4();
	Buzzer_init();
	LED_init();
	Key_Init();
	while(1){
		//vu8 key = KeyScan();
		//if(key)
		//{
			int count= 8;
			while(count != 0)
			{
				GPIO_SetBits(GPIOA,GPIO_Pin_5);
				delay_ms(150*count);
				GPIO_ResetBits(GPIOA,GPIO_Pin_5);
				delay_ms(150*count);
				count--;
			}
			delay_ms(1500);
			while (1)
			{
				i = 0;
				while (melody[i] != 0xff)
				{
					tune = (1000 * 1000 / 2) / melody[i];
					SysTick_Init(tune);
					GPIO_SetBits(GPIOA,GPIO_Pin_5);
					for (j = 0; j < beats[i]; j++)
					{
						delay_ms(50);
					}
					GPIO_ResetBits(GPIOA,GPIO_Pin_5);
					GPIO_SetBits(GPIOB,GPIO_Pin_8);
					for (j = 0; j < beats[i]; j++)
					{
						delay_ms(75);
					}
					i++;
				}
			}
		//}
	}
}
