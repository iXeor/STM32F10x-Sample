#include"stm32f10x.h"

#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2))
#define MEM_ADDR(addr) *((volatile unsigned long *)(addr))
#define BIT_ADDR(addr, bitnum) MEM_ADDR(BITBAND(addr, bitnum))
#define GPIOA_ODR_Addr (GPIOA_BASE+12)
#define LED_0 BIT_ADDR(GPIOA_ODR_Addr,5) //LED0��ӦPA5
#define KEY0 GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_13)
#define KEY_PRESS 1

void delay_ms(int32_t ms)
{
    int32_t i;
    while(ms--)
    {
        i = 7500;
        while(i--);
    }
}

void LED_Init()
{
	GPIO_InitTypeDef G;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	G.GPIO_Speed=GPIO_Speed_50MHz;
	G.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA,&G);
	GPIO_SetBits(GPIOA,GPIO_Pin_5);
}

void Key_Init()
{
	GPIO_InitTypeDef G;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	G.GPIO_Pin = GPIO_Pin_13;
	G.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_Init(GPIOC,&G);
}

uint8_t KeyScan()
{
	if(KEY0==0)
	{
		delay_ms(10);
		if(KEY0==0)
			return KEY_PRESS;
		else
			return 0;
	}
	else
		return 0;
}

int main()
{
	vu8 key = 1;
	LED_Init();
	Key_Init();
	LED_0 = 0;
	while(1)
	{
		key = KeyScan();
		if(key)
		{
			LED_0 = 0;
		}
		else LED_0 = 1;
	}
}
