#include "stm32f10x.h"

void delay_ms(int32_t ms)
{
    int32_t i;
    while(ms--)
    {
        i = 7500;
        while(i--);
    }
}

int main()
{
    uint8_t k;
    GPIO_InitTypeDef G;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
    G.GPIO_Pin = GPIO_Pin_5;
    G.GPIO_Mode = GPIO_Mode_Out_PP;
    G.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB,&G);
    for(k=0;k<5;k++)
    {
        GPIO_SetBits(GPIOB,GPIO_Pin_5);
        delay_ms(500);
        GPIO_ResetBits(GPIOB,GPIO_Pin_5);
        delay_ms(500);
    }
    while(1)
    {
        GPIO_SetBits(GPIOB,GPIO_Pin_5);
        delay_ms(2500);
        GPIO_ResetBits(GPIOB,GPIO_Pin_5);
        delay_ms(2500);
    }
}
