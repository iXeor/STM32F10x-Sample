#define LED_ON 1
#define LED_OFF 0
#define LED_PB5 1
#define LED_PE5 0
#include "stm32f10x.h"

void NVIC_Conf(){
	NVIC_InitTypeDef N;
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	N.NVIC_IRQChannel = TIM3_IRQn;
	N.NVIC_IRQChannelSubPriority = 1;
	N.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&N);
}
void LED_Sta(int LEDPin,int mode){
	if(LEDPin == LED_PB5){
		if(mode == LED_ON)
				GPIO_ResetBits(GPIOB,GPIO_Pin_5);
			else
				GPIO_SetBits(GPIOB,GPIO_Pin_5);
	}
	else if(LEDPin == LED_PE5){
		if(mode == LED_ON)
						GPIO_ResetBits(GPIOE,GPIO_Pin_5);
					else
						GPIO_SetBits(GPIOE,GPIO_Pin_5);
	}
}
void LED_Conf(){
	GPIO_InitTypeDef G;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOE,ENABLE);
	G.GPIO_Pin = GPIO_Pin_5;
	G.GPIO_Mode = GPIO_Mode_Out_PP;
	G.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&G);
	G.GPIO_Pin = GPIO_Pin_5;
	GPIO_Init(GPIOE,&G);
	LED_Sta(LED_PB5,LED_OFF);
	LED_Sta(LED_PE5,LED_OFF);
}
void LED_Trigger(){
	GPIO_WriteBit(GPIOB,GPIO_Pin_5,(BitAction)(1-GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_5)));
	GPIO_WriteBit(GPIOE,GPIO_Pin_5,(BitAction)(1-GPIO_ReadOutputDataBit(GPIOE,GPIO_Pin_5)));
}
void TIM3_Conf(){
	TIM_TimeBaseInitTypeDef T;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	T.TIM_Prescaler = 3599;
	T.TIM_CounterMode = TIM_CounterMode_Up;
	T.TIM_Period = 40000;
	TIM_TimeBaseInit(TIM3,&T);
	TIM_ITConfig(TIM3,TIM_IT_Update|TIM_IT_Trigger,ENABLE);
	TIM_Cmd(TIM3,ENABLE);
}
void PPP_IRQHandler(){}
void TIM3_IRQHandler(){
	if(TIM_GetITStatus(TIM3,TIM_IT_Update) == SET){
		LED_Trigger();
		TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
	}
}
void delay_ms(int32_t ms){
	int32_t i;
	while(ms--){
		i = 7500;
		while(i--);
	}
}
int main(){
	uint8_t k;
	NVIC_Conf();
	LED_Conf();
	TIM3_Conf();
	for(k = 0;k < 5;k++){
		LED_Sta(LED_PB5,LED_ON);
		LED_Sta(LED_PE5,LED_OFF);
		delay_ms(100);
		LED_Sta(LED_PE5,LED_ON);
		LED_Sta(LED_PB5,LED_OFF);
		delay_ms(100);
	}
	while(1){
	}
}
